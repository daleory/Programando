package tallerprogrambasica;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author daleo
 */
public class Funciones {

    public static void operaciones() {
        Scanner escaner = new Scanner(System.in);
        System.out.println("Digite el primer número entero: ");
        int num1 = escaner.nextInt();
        System.out.println("Digite el segundo número entero: ");
        int num2 = escaner.nextInt();
        int sum = num1 + num2;
        int rest = num1 - num2;
        int resid;

        if (num1 > num2) {
            resid = num1 % num2;
        } else {
            resid = num2 % num1;
        }
        System.out.println("El Resultado de la Suma es: " + sum);
        System.out.println("El Resultado de la resta es: " + rest);
        System.out.println("El Residuo es: " + resid);
    }

    public static void reinoAnimal() {
        Scanner entrada = new Scanner(System.in);
        String bacteria, algas, hongo, flores, insecto;
        String serVivo;
        System.out.println("Escriba una de las siguientes opciones: ");
        System.out.println("bacteria - algas - hongo - flores - insecto ");
        serVivo = entrada.nextLine();

        if (serVivo.equalsIgnoreCase("bacteria")) {
            System.out.println("El Ser Vivo " + serVivo + ", Pertenece al Reino Monera");
        } else {
            if (serVivo.equalsIgnoreCase("algas")) {
                System.out.println("El Ser Vivo " + serVivo + ", Pertenece al Reino Protista");
            } else {
                if (serVivo.equalsIgnoreCase("hongo")) {
                    System.out.println("El Ser Vivo " + serVivo + ", Pertenece al Reino Fungi");
                } else {
                    if (serVivo.equalsIgnoreCase("flores")) {
                        System.out.println("El Ser Vivo " + serVivo + ", Pertenece al Reino Vegetal");
                    } else if (serVivo.equalsIgnoreCase("insecto")) {
                        System.out.println("El Ser Vivo " + serVivo + ", Pertenece al Reino Animal");
                    }
                }
            }
        }
    }

    public static void notaMusical() {
        int num = Integer.parseInt(JOptionPane.showInputDialog(null, "ingrese un dígito del 1 al 7"));

        switch (num) {
            case 1:
                JOptionPane.showMessageDialog(null, "El dígito ingresado corresponde a la nota musical: " + "DO");
                break;
            case 2:
                JOptionPane.showMessageDialog(null, "El dígito ingresado corresponde a la nota musical: " + "RE");
                break;
            case 3:
                JOptionPane.showMessageDialog(null, "El dígito ingresado corresponde a la nota musical: " + "MI");
                break;
            case 4:
                JOptionPane.showMessageDialog(null, "El dígito ingresado corresponde a la nota musical: " + "FA");
                break;
            case 5:
                JOptionPane.showMessageDialog(null, "El dígito ingresado corresponde a la nota musical: " + "SOL");
                break;
            case 6:
                JOptionPane.showMessageDialog(null, "El dígito ingresado corresponde a la nota musical: " + "LA");
                break;
            case 7:
                JOptionPane.showMessageDialog(null, "El dígito ingresado corresponde a la nota musical: " + "SI");
                break;
            default:
                JOptionPane.showMessageDialog(null, "El dígito ingresado no se encuentra entre el 1 y el 7");
        }
    }

    public static void forValor() {
        int num = Integer.parseInt(JOptionPane.showInputDialog(null, "ingrese un número entero positivo"));

        for (int i = 0; i <= num; i++) {
            JOptionPane.showMessageDialog(null, i);
        }
    }

    public static void for3en3() {
        int num = Integer.parseInt(JOptionPane.showInputDialog(null, "ingrese un número entero positivo"));

        for (int i = 0; i <= num; i = i + 3) {
            JOptionPane.showMessageDialog(null, i);
        }
    }

    public static void parImpar() {
        int num = Integer.parseInt(JOptionPane.showInputDialog(null, "ingrese un número entero "));

        if (num % 2 == 0) {
            JOptionPane.showMessageDialog(null, "El Número " + num + " es par");
        } else {
            JOptionPane.showMessageDialog(null, "El Número " + num + " es impar");
        }
    }

    public static void fibonacci() {
        int num = Integer.parseInt(JOptionPane.showInputDialog(null, "ingrese un número entero positivo"));
        int a = 1, b = 0, c = 0;

        while (c <= num) {
            c = a + b;
            a = b;
            b = c;
            JOptionPane.showMessageDialog(null, a);
        }
    }

    public static void claveSecreta() {
        int clave = 26;
        int i = 1;//2,3
        int j = 2;//1,0

        JOptionPane.showMessageDialog(null, "Su Clave se encuentra en el Rango de números entre 20 y 35");
        while (i <= 3) {
            int num = Integer.parseInt(JOptionPane.showInputDialog(null, "Por Favor Ingrese su Clave"));
            if (num >= 20 & num <= 35) {

                if (num == clave) {
                    JOptionPane.showMessageDialog(null, "Acceso Permitido");

                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Acceso Denegado");
                    JOptionPane.showMessageDialog(null, "Le quedan " + j + " intentos.");
                    i++;
                    j--;

                    if (j < 0) {
                        JOptionPane.showMessageDialog(null, "Clave bloqueada.");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Número ingresado no Válido");
            }
        }
    }

    public static void creatividad() {
        /*Efecto Amor = el Numero inferior se le suma 1 y el numero superior se le resta uno, con el fin
        de que los numeros se vayan acercando y terminen juntos para siempre... amén*/
         
        int infe = Integer.parseInt(JOptionPane.showInputDialog(null, "Por Favor Ingrese Número Entero Inferior"));
        int supe = Integer.parseInt(JOptionPane.showInputDialog(null, "Por Favor Ingrese Número Entero Superior"));

        if (infe < supe) {
            for (int i = infe; i <= supe; i++) {
                if (i < supe) {
                    JOptionPane.showMessageDialog(null, i + ",");
                    JOptionPane.showMessageDialog(null, supe + ",");
                }
                supe--;
            }
        } else {
            JOptionPane.showMessageDialog(null, "Error: El Primer Número ingresado no es Menor que el segundo Número");
        }
    }
}
